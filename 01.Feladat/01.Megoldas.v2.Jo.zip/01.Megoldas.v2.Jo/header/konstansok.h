#ifndef KONSTANSOK_H
#define KONSTANSOK_H

#define NUMBER_OF_NODE 1000
#define CONNECTION_CHANCE 75
#define save_path "/home/biro/Dokumentumok/programozas/c/NYE.PTI.Jatekelmelet/01.Feladat/01.Megoldas.v2/results/res_"

#define MIN_WEIGHT 1
#define MAX_WEIGHT 9

#define NUMBER_OF_TESTS 100

/*
    Saját boolean típus
*/
#define True 1
#define False 0
typedef int boolean;

#endif //KONSTANSOK_H