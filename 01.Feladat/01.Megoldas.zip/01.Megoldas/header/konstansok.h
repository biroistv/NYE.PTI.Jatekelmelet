#ifndef KONSTANSOK_H
#define KONSTANSOK_H

#define CSUCSOK_SZAMA 1000      
#define KAPCSOLODAS_ESELYE 60  // A csúcshoz kapcsolódás %-os esélye
#define output "szamok.txt"

#define MINIMALIS_KOLTSEG 1
#define MAXIMALIS_KOLTSEG 9

#define TESZTEK_SZAMA 1000

/*
    Saját boolean típus
*/
#define True 1
#define False 0
typedef int boolean;

#endif //KONSTANSOK_H